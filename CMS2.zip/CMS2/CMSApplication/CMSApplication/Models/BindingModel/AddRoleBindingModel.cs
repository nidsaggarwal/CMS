﻿namespace CMSApplication.Models.BindingModel
{
    public class AddRoleBindingModel
    {
        public string Role { get; set; }
    }
}
