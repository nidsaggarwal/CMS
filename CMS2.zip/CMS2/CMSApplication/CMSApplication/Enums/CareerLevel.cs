﻿namespace CMSApplication.Enums
{
    public enum CareerLevel
    {
        Intern = 100,
        Entry = 99,
        Mid = 98,
        Senior = 97,

    }
}
