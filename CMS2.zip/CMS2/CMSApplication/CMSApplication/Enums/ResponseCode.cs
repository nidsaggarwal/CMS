﻿namespace CMSApplication.Enums
{
    public enum ResponseCode
    {
        OK = 1 ,
        Error = 2 ,
    }
}
