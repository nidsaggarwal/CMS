﻿namespace CMSApplication.Enums
{
    public enum UserRole : byte
    {
        Admin = 1,
        User,
    }
}
