import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-list-feedback',
  templateUrl: './list-feedback.component.html',
  styleUrls: ['./list-feedback.component.css']
})
export class ListFeedbackComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
