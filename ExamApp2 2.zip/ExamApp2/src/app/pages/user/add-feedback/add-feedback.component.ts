import {Component, Input, OnInit} from '@angular/core';
import Swal from 'sweetalert2';
import {FeedbackService} from '../../../services/feedback.service';
import {MatSnackBar} from '@angular/material/snack-bar';

@Component({
  selector: 'app-add-feedback',
  templateUrl: './add-feedback.component.html',
  styleUrls: ['./add-feedback.component.css']
})
export class AddFeedbackComponent implements OnInit {


  feedback = {
    fullName: '',
    Email: '',
    ContactNo: '',
    Comments: ''
  };




    @Input('rating') private rating: number = 3;
    @Input('starCount') private starCount: number = 5;
    @Input('color') private color: string = 'accent';

    private snackBarDuration: number = 2000;
    private ratingArr = [];

    // tslint:disable-next-line:variable-name
    constructor(private _feedback: FeedbackService,  private _snack: MatSnackBar) { }

  ngOnInit(): void {
      console.log("a "+this.starCount);
      for (let index = 0; index < this.starCount; index++) {
          this.ratingArr.push(index);
  }


      onClick(rating:number) {
          console.log(rating);
          this._snack.open('You rated ' + rating + ' / ' + this.starCount, '', {
              duration: this.snackBarDuration
          });
          this.ratingUpdated.emit(rating);
          return false;
      }

      showIcon(index:number) {
          if (this.rating >= index + 1) {
              return 'star';
          } else {
              return 'star_border';
          }
      }

  }

  formSubmit() {
    if (this.feedback.fullName.trim() == '' || this.feedback.fullName == null) {
      this._snack.open('Name  Required !!', '', {
        duration: 3000,
      });
      return;
    }

    //all done

    this._feedback.addFeedback(this.feedback).subscribe(
        (data: any) => {
          this.feedback.fullName = '';
          this.feedback.Email = '';
          this.feedback.ContactNo = '';
          this.feedback.Comments = '';

          Swal.fire('Success !!', 'Category is added successfuly', 'success');
        },
        (error) => {
          console.log(error);
          Swal.fire('Error !!', 'Server error !!', 'error');
        }
    );
  }

}

export enum StarRatingColor {
    primary = "primary",
    accent = "accent",
    warn = "warn"
}
