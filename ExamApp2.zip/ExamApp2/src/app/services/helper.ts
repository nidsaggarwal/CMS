import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'objectToArray',
})
export class ObjectToArrayPipe implements PipeTransform {
  // The object parameter represents the values of the properties or index.
  transform = (objects: any = []) => {
    return Object.values(objects);
  }
}

export class Constants{
    public static readonly USER_KEY:string="userInfo";

}

let baseUrl = 'https://localhost:7046/api';
export default baseUrl;
